// Platz für spätere Helper-Funktionen.
console.log("tools/helpers.js geladen (Demo)");
