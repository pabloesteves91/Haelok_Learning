// Platzhalterdatei für spätere Cloud Functions.
exports.placeholder = () => {
  console.log("Cloud Function placeholder");
};
